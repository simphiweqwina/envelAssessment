import json
import boto3
from botocore.exceptions import ClientError


def lambda_handler(event, context):
    client = boto3.resource('dynamodb')
    table = client.Table('EnvelUser')
    response = table.scan()
    data = response['Items']
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
        'body': json.dumps(data)
    }
