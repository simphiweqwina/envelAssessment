import json
import boto3


def lambda_handler(event, context):
    # TODO implement
    client = boto3.resource('dynamodb')
    table = client.Table('EnvelUser')
    
    
    print(event)
    input = {'username':event['userName']}
    
    response = table.put_item(Item=input)
    return {
        'statusCode': 200,
        'body': 'user saved '
    }
